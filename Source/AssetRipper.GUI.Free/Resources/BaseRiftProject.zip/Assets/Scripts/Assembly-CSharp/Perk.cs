using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

[CreateAssetMenu(fileName = "Perk_New", menuName = "White Knuckle/Perk")]
public class Perk : ScriptableObject
{
	[Serializable]
	public class PerkSaveData
	{
		public string id;

		public int stackAmount;

		public List<PerkModule.PerkModuleSaveInfo> modules;

		public static PerkSaveData GetPerkSaveData(Perk p)
		{
			return new PerkSaveData
			{
				id = p.id,
				stackAmount = p.GetStackAmount(),
				modules = p.GetPerkModuleSaveInfos()
			};
		}

		public static void SetPerkSaveData(Perk p, PerkSaveData data)
		{
			Debug.Log("Setting Perk Save Data: " + p.name);
			p.stackAmount = data.stackAmount;
			if (p.modules == null || p.modules.Count <= 0 || data.modules == null || data.modules.Count <= 0)
			{
				return;
			}
			for (int i = 0; i < Mathf.Min(p.modules.Count, data.modules.Count); i++)
			{
				if (p.modules[i] != null && data.modules[i] != null)
				{
					p.modules[i].LoadSaveData(data.modules[i]);
				}
			}
		}
	}

	public enum PerkPool
	{
		standard = 0,
		unstable = 1,
		never = 2
	}

	public enum PerkType
	{
		standard = 0,
		orange = 1,
		red = 2,
		unstable = 3,
		peripheral = 4,
		delta = 5,
		rho = 6,
		kappa = 7,
		trinket = 8,
		binding = 9
	}

	public List<string> tags = new List<string> { "basic" };

	public string title;

	public string id;

	public string description;

	public string flavorText;

	public PerkType perkType;

	public int sortingCategory = 1;

	public bool competitive = true;

	[Tooltip("Should this perk be removed in some circumstances (Rho Chambers, etc)")]
	public bool removeOnCleanse = true;

	[Space]
	public int cost;

	[Space]
	public PerkPool spawnPool;

	public bool spawnInEndless = true;

	public bool canStack = true;

	[Space]
	public int stackMax;

	public AnimationCurve multiplierCurve;

	[Space]
	public bool useBuff = true;

	public BuffContainer buff;

	public bool useBaseBuff;

	public BuffContainer baseBuff;

	public float buffMultiplier = 1f;

	public List<string> flags;

	public List<string> playerTag;

	[SerializeReference]
	public List<PerkModule> modules;

	public Sprite icon;

	public Material iconMat;

	public Sprite perkCard;

	public Sprite perkFrame;

	public SpawnTable.SpawnSettings spawnSettings;

	public int stackAmount;

	private BuffContainer currentBuff;

	private BuffContainer currentBaseBuff;

	internal ENT_Player player;

	public string unlockProgressionID;

	public int unlockXP;

	private float barValue = 1f;

	public Action<Perk> _OnPerkDestroy;

	private bool isActive = true;

	internal Guid guid;

	public void Initialize(ENT_Player p, bool firstTime = true)
	{
		player = p;
		if (useBuff)
		{
			if (buff.id != "")
			{
				currentBuff = player.curBuffs.GetBuffContainer(buff.id);
				if (useBaseBuff)
				{
					currentBaseBuff = player.curBuffs.GetBuffContainer(baseBuff.id);
				}
			}
			if (currentBuff == null)
			{
				player.curBuffs.AddBuff(buff);
				if (useBaseBuff)
				{
					player.curBuffs.AddBuff(baseBuff);
				}
				currentBuff = player.curBuffs.GetBuffContainer(buff.id);
				if (useBaseBuff)
				{
					currentBaseBuff = player.curBuffs.GetBuffContainer(baseBuff.id);
				}
			}
			currentBuff.SetMultiplier(1f * buffMultiplier);
		}
		if (stackAmount <= 0)
		{
			stackAmount = 1;
		}
		if (flags != null)
		{
			foreach (string flag in flags)
			{
				CL_GameManager.SetGameFlag(flag, state: true);
			}
		}
		foreach (string item in playerTag)
		{
			player.GetTagger().AddTag(item);
		}
		if (modules != null && modules.Count > 0)
		{
			for (int num = modules.Count - 1; num >= 0; num--)
			{
				modules[num].Initialize(this);
				modules[num].AddModule(stackAmount, firstTime);
			}
		}
		guid = Guid.NewGuid();
	}

	public void Update()
	{
		float num = 1f;
		if (stackAmount > 1)
		{
			for (int i = 1; i < Mathf.Min(stackAmount, stackMax); i++)
			{
				num += multiplierCurve.Evaluate((float)i / (float)stackMax);
			}
		}
		if (useBuff)
		{
			currentBuff.SetMultiplier(num);
		}
		if (!CL_GameManager.gMan.isPaused)
		{
			for (int num2 = modules.Count - 1; num2 >= 0; num2--)
			{
				modules[num2].Update();
			}
		}
	}

	public void AddStack(int amount = 1, bool firstTime = true)
	{
		stackAmount += amount;
		foreach (PerkModule module in modules)
		{
			module.AddModule(amount, firstTime);
		}
	}

	internal void RemoveStack(int amount = 1)
	{
		stackAmount -= amount;
	}

	public int GetStackAmount()
	{
		return stackAmount;
	}

	public bool CanSpawn()
	{
		Debug.Log("Checking Perk: " + base.name + " - " + unlockProgressionID);
		if (!spawnInEndless && CL_GameManager.gamemode.isEndless)
		{
			return false;
		}
		if (CL_GameManager.GetCurrentGamemode().IsCompetitive() && !competitive)
		{
			return false;
		}
		if (ENT_Player.GetPlayer().HasPerk(id))
		{
			if (!canStack)
			{
				Debug.Log("Blocking stack: Already has " + id);
				return false;
			}
			Perk perk = ENT_Player.GetPlayer().GetPerk(id);
			if (perk.stackMax <= perk.stackAmount)
			{
				Debug.Log("Blocking stack: Has enough " + id);
				return false;
			}
		}
		if (!canStack && ENT_Player.GetPlayer().HasPerk(id))
		{
			return false;
		}
		if (unlockProgressionID != "" && !CL_ProgressionManager.HasProgressionUnlock(unlockProgressionID))
		{
			return false;
		}
		if (CL_ProgressionManager.playerExperience < unlockXP)
		{
			return false;
		}
		return spawnSettings.RandomCheck();
	}

	public void RemoveFromPlayer()
	{
		Debug.Log("Removing Perk: " + id);
		OnDestroy();
		player.RemovePerk(this);
		isActive = false;
	}

	public void OnDestroy()
	{
		foreach (PerkModule module in modules)
		{
			module.OnDestroy(this);
		}
		_OnPerkDestroy?.Invoke(this);
	}

	public void ClearPerkEffects()
	{
		if (useBuff)
		{
			player.curBuffs.RemoveBuffContainer(currentBuff.id);
		}
		if (useBaseBuff)
		{
			player.curBuffs.RemoveBuffContainer(currentBaseBuff.id);
		}
		OnDestroy();
		if (flags != null)
		{
			foreach (string flag in flags)
			{
				CL_GameManager.SetGameFlag(flag, state: false);
			}
		}
		foreach (string item in playerTag)
		{
			player.GetTagger().RemoveTag(item);
		}
	}

	public float GetBarValue()
	{
		return barValue;
	}

	public void SetBarValue(float f)
	{
		barValue = f;
	}

	public bool IsActive()
	{
		return isActive;
	}

	internal void RemoveModule(PerkModule module)
	{
		modules.Remove(module);
	}

	public List<PerkModule.PerkModuleSaveInfo> GetPerkModuleSaveInfos()
	{
		List<PerkModule.PerkModuleSaveInfo> list = new List<PerkModule.PerkModuleSaveInfo>();
		foreach (PerkModule module in modules)
		{
			PerkModule.PerkModuleSaveInfo perkModuleSaveInfo = new PerkModule.PerkModuleSaveInfo();
			perkModuleSaveInfo.perkModuleType = module.GetType().ToString();
			perkModuleSaveInfo.data = module.GetSaveData();
			Debug.Log("PM Type: " + perkModuleSaveInfo.perkModuleType);
			list.Add(perkModuleSaveInfo);
		}
		return list;
	}

	public string GetTitle(bool includeColor = false)
	{
		if (includeColor)
		{
			if (perkType == PerkType.orange)
			{
				return "<color=#FFD454><shimmer s=0.1>" + title + "</shimmer></color>";
			}
			if (perkType == PerkType.red)
			{
				return "<color=#ED4040>" + title + "</color>";
			}
			if (perkType == PerkType.rho)
			{
				return "<color=#ED4040><shimmer s=0.1><shake a=0.02>" + title + "</shake></shimmer></color>";
			}
			if (perkType == PerkType.unstable)
			{
				return "<color=#ff61a3><shake a=0.003>" + title + "</shake></color>";
			}
			if (perkType == PerkType.delta)
			{
				return "<color=#54FFBD><shimmer s=0.1>" + title + "</shimmer></color>";
			}
			if (perkType == PerkType.kappa)
			{
				return "<color=#c2edff><shimmer s=0.1><shake a=0.005>" + title + "</shake></shimmer></color>";
			}
			if (perkType == PerkType.trinket)
			{
				return "<color=#FF8AFF>Trinket\n<shimmer s=0.1>" + title + "</shimmer></color>";
			}
			if (perkType == PerkType.binding)
			{
				return "<color=#808080>Binding\n<shimmer s=0.1><shake a=0.01>" + title + "</shake></shimmer></color>";
			}
			return "<color=\"white\">" + title + "</color>";
		}
		return title;
	}

	public string GetDescription(bool adjusted = false, bool total = false, bool includeFlavor = true, bool includeColorTags = true)
	{
		Perk playerPerk = ENT_Player.GetPlayer().GetPerk(id);
		string text = description;
		if (includeColorTags)
		{
			text = text.Replace("(+)", "<color=\"grey\">+ </color>");
			text = text.Replace("(-)", "<color=#915757>- </color>");
		}
		string text2 = FillData(text, delegate(string content)
		{
			bool flag = false;
			if (content.Contains("%"))
			{
				flag = true;
				content = content.Replace("%", "");
			}
			if (playerPerk == null)
			{
				foreach (BuffContainer.Buff buff in buff.buffs)
				{
					if (content == buff.id)
					{
						Debug.Log(buff.id + " " + buff.maxAmount);
						if (flag)
						{
							return Mathf.Round(buff.maxAmount * 100f).ToString();
						}
						return Math.Round(buff.maxAmount, 2).ToString();
					}
				}
				foreach (BuffContainer.Buff buff2 in this.buff.buffs)
				{
					if (content == buff2.id)
					{
						if (flag)
						{
							return Mathf.Round(buff2.maxAmount * 100f).ToString();
						}
						return Math.Round(buff2.maxAmount, 2).ToString();
					}
				}
				return "?";
			}
			foreach (BuffContainer.Buff buff3 in playerPerk.buff.buffs)
			{
				if (content == buff3.id)
				{
					if (adjusted)
					{
						if (total)
						{
							float num = 0f;
							for (int i = 0; i < playerPerk.stackAmount; i++)
							{
								num += multiplierCurve.Evaluate((float)i / (float)stackMax);
							}
							if (flag)
							{
								return Mathf.Round(buff3.maxAmount * 100f * num).ToString();
							}
							return Math.Round(buff3.maxAmount * num, 2).ToString();
						}
						float num2 = multiplierCurve.Evaluate((float)playerPerk.stackAmount / (float)stackMax);
						if (flag)
						{
							return Mathf.Round(buff3.maxAmount * 100f * num2).ToString();
						}
						return Math.Round(buff3.maxAmount * num2, 2).ToString();
					}
					return Mathf.Round(buff3.maxAmount * 100f).ToString();
				}
			}
			return "?";
		});
		if (includeFlavor && !string.IsNullOrEmpty(flavorText) && includeColorTags)
		{
			text2 += "<color=\"grey\"><size=12><i>\n<i>";
		}
		if (includeFlavor && !string.IsNullOrEmpty(flavorText))
		{
			text2 += flavorText;
		}
		return text2;
		static string FillData(string input, Func<string, string> replacer)
		{
			return Regex.Replace(input, "\\{(.*?)\\}", delegate(Match match)
			{
				string value = match.Groups[1].Value;
				return replacer(value);
			});
		}
	}
}
