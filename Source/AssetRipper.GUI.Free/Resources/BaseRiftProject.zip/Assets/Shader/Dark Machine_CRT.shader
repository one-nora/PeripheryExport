Shader "Dark Machine/CRT"
{
    Properties
    {
        _Color ("Color", Color) = (1,1,1,1)
        _MainTex ("Texture", 2D) = "white" {}
        _VignetteTex ("Vignette", 2D) = "white" {}
        _VignetteColor ("Vignette Color", Color) = (1,1,1,1)

        _DistortionTex ("Distortion", 2D) = "black" {}
        _DistortionAmount ("Distortion Amount", float) = 0.0

        _DisplacementTex ("Displacement", 2D) = "black" {}
        _DisplacementAmount ("Displacement Amount", float) = 0.0


        _LineWidth ("Scanline Width", float) = 0.0
        _LineAmount ("Scanline Amount", Range (0, 1)) = 0.0
        _LineSpeed ("Scanline Speed", float) = 0.0

        _Brightness ("Brightness", float) = 1.0
        _DitherAmount ("Dither", float) = 0.0


    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            CGPROGRAM
            
            #pragma vertex vert
            #pragma fragment frag
            // make fog work
            #pragma multi_compile_fog

            #include "UnityCG.cginc"
            #include "DarkMachine.cginc"

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float2 uv : TEXCOORD0;
                float4 vertex : SV_POSITION;
                float4 screenPos : SCREENUV;
                float3 worldPos : WORLDPOSITION;
            };

            sampler2D _MainTex;
            float4 _MainTex_ST;
            sampler2D _VignetteTex;

            sampler2D _DistortionTex;
            float4 _DistortionTex_ST;

            sampler2D _DisplacementTex;
            float _DisplacementAmount;

            float _DistortionAmount;

            float4 _Color;

            float4 _VignetteColor;

            float _LineAmount;
            float _LineWidth;
            float _LineSpeed;

            float _Brightness;
            float _DitherAmount;

            v2f vert (appdata v)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.uv = TRANSFORM_TEX(v.uv, _MainTex);

                o.screenPos = ComputeScreenPos(o.vertex);
                o.worldPos = mul(unity_ObjectToWorld, v.vertex).xyz;
                
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {

                float2 uv = i.uv;

                float glitchTime = cos(_Time.x * 2.3);
                float glitchAmount = clamp(sin((_Time.x) * 100) + glitchTime,-.2,1);
                glitchAmount *= 3;

                fixed4 distort = tex2D(_DistortionTex, (uv * _DistortionTex_ST.xy) + _Time.x * 3.5);
                    
                uv += ((distort)* _DistortionAmount * glitchAmount);

                fixed4 displace = tex2D(_DisplacementTex, uv) * _DisplacementAmount;

                uv += displace;
                // sample the texture
                fixed4 col = tex2D(_MainTex, uv);

                
                // Get dither value
                float screenspaceDither = ScreenspaceDither(i.screenPos);

                col += sin(uv.y * _LineWidth + _Time.x * _LineSpeed) * _LineAmount;

                col.r = PosterizeValue(col.r + screenspaceDither * _DitherAmount, 64);
                col.g = PosterizeValue(col.g + screenspaceDither * _DitherAmount, 64);
                col.b = PosterizeValue(col.b + screenspaceDither * _DitherAmount, 64);

                col.rgb = (col.rgb) * _Color;
                
				// Calculate the distance from the camera to the fragment
                float3 cameraPos = _WorldSpaceCameraPos;
				float dist = distance(cameraPos, i.worldPos);

                float4 vignette = tex2D(_VignetteTex, i.uv);
                col.rgb *= lerp(vignette, 1, 0.5);
                col.rgb += vignette * _VignetteColor;

                col.rgb = CalculateFog(col.rgb, dist, screenspaceDither, i.worldPos);

                col.rgb *= _Brightness;
                return col;
            }
            ENDCG
        }
    }
}
