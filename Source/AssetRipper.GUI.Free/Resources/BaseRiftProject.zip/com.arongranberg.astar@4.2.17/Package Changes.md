Changes made to make it work with white knuckle
- Made AddGraph public (Core/AstarData.cs)
- Remove updater (Editor/AstarUpdateChecker.cs)
- Add PathfindingTag